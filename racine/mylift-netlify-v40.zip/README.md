# MyLift — Build Netlify (v3 propre)

## Déploiement

1. **Décompresse** ce zip → tu obtiens un dossier `mylift-build/`
2. Va sur https://app.netlify.com → ton site `mylift-v2`
3. Onglet **"Deploys"**
4. Scroll en bas de la liste des deploys → zone "Need to update your site? Drag and drop..."
5. **Drag-and-drop le dossier `mylift-build`** (pas le zip)
6. Attends 10-20 sec → URL live

## Si l'erreur "SgSliderRow already declared" persiste

Le cache du service worker peut servir un ancien fichier. Solutions :

1. **Ouvre en navigation privée** pour vérifier sans cache
2. **Unregister le SW** : F12 → Application → Service Workers → Unregister
3. **Clear site data** : F12 → Application → Storage → Clear site data

## Contenu

- `index.html` (3 KB — shell + loader)
- `app.jsx` (455 KB — ton code React complet, UNE seule déclaration SgSliderRow)
- `sw.js` (cache v4-2026-04-19, network-first pour HTML/JSX)
- `manifest.webmanifest`
- `icon-192.png`, `icon-512.png`
- `_redirects` (SPA fallback)
